﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using BikeStore.Models;
using MimeKit;
using MailKit.Net.Smtp;
using System.Security.Cryptography;
using Microsoft.AspNetCore.Cryptography.KeyDerivation;

namespace BikeStore.Controllers
{
    public class UserAccountsController : Controller
    {
        private readonly AdventureWorksLT2017Context db;

        public UserAccountsController(AdventureWorksLT2017Context context)
        {
            db = context;
        }

        // GET: UserAccounts
        public async Task<IActionResult> Index()
        {
            return View(nameof(Login));
        }

        // GET: UserAccounts/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var userAccount = await db.UserAccount
                .FirstOrDefaultAsync(m => m.Id == id);
            if (userAccount == null)
            {
                return NotFound();
            }

            return View(userAccount);
        }

        // GET: UserAccounts/Register
        public IActionResult Register()
        {
            if (HttpContext.Request.Cookies["user_id"] != null)
                return RedirectToAction("index", "Home");
            return View();
        }

        // POST: UserAccounts/Register
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Register([Bind("FirstName,LastName,Email,PostalCode,Password,ConfirmPassword")] UserAccount userAccount)
        {
            // Query db for users with duplicate email
            var user = db.UserAccount.FirstOrDefault(x => x.Email == userAccount.Email);
            
            if (user != null)
            {
                ViewBag.Message = "Duplicate email address entered";
            }
            else if (ModelState.IsValid)
            {
                if (!SendEmail(userAccount))
                {
                    return View("/Views/UserAccounts/Failure.cshtml");
                }

                userAccount.TimeStamp = DateTime.Now;


                //Code adapted from https://docs.microsoft.com/en-us/aspnet/core/security/data-protection/consumer-apis/password-hashing?view=aspnetcore-5.0
                string password = userAccount.Password;

                // generate a 128-bit salt using a secure PRNG
                byte[] salt = new byte[128 / 8];
                using (var rng = RandomNumberGenerator.Create())
                {
                    rng.GetBytes(salt);
                }
                string stringSalt = Convert.ToBase64String(salt);
                
                // derive a 256-bit subkey (use HMACSHA1 with 10,000 iterations)
                string hashed = Convert.ToBase64String(KeyDerivation.Pbkdf2(
                    password: password,
                    salt: salt,
                    prf: KeyDerivationPrf.HMACSHA1,
                    iterationCount: 10000,
                    numBytesRequested: 256 / 8));


                userAccount.PasswordHash = hashed;
                userAccount.PasswordSalt = stringSalt;
                db.Add(userAccount);
                await db.SaveChangesAsync();
                user = db.UserAccount.FirstOrDefault(x => x.Email == userAccount.Email);
                HttpContext.Response.Cookies.Append("user_id", user.Id.ToString());
                HttpContext.Response.Cookies.Append("first_name", user.FirstName.ToString());
                HttpContext.Response.Cookies.Append("last_name", user.LastName.ToString());
                return RedirectToAction(nameof(Manage), new { id = user.Id });
            }
            return View(userAccount);
        }


        public IActionResult Login()
        {
            if (HttpContext.Request.Cookies["user_id"] != null)
                return RedirectToAction("index", "Home");
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Login([Bind("Id,Email,Password")] UserAccount userAccount)
        {
            // Query db for users with duplicate email
            var user = db.UserAccount.FirstOrDefault(x => x.Email == userAccount.Email);


            if (user == null)
            {
                ViewBag.Message = "Incorrect Email";
            }
            else    //Successful login
            {
                //do hash thingy

                string hashed = Convert.ToBase64String(KeyDerivation.Pbkdf2(
                    password: userAccount.Password,
                    salt: Convert.FromBase64String(user.PasswordSalt),
                    prf: KeyDerivationPrf.HMACSHA1,
                    iterationCount: 10000,
                    numBytesRequested: 256 / 8));

                if(hashed != user.PasswordHash)
                {
                    ViewBag.Message = "Incorrect Password";
                }
                else
                {
                    UserLoginLog loginLog = new UserLoginLog();
                    loginLog.Id = user.Id;
                    loginLog.TimeStamp = DateTime.Now;
                    db.Add(loginLog);
                    await db.SaveChangesAsync();

                    HttpContext.Response.Cookies.Append("user_id", user.Id.ToString());
                    HttpContext.Response.Cookies.Append("first_name", user.FirstName.ToString());
                    HttpContext.Response.Cookies.Append("last_name", user.LastName.ToString());
                    return RedirectToAction("index", "Home");
                }
            }   
            return View(userAccount);
        }

        public async Task<IActionResult> GoogleLogin()
        {
            //Check if user exists in DB
            var user = db.UserAccount.FirstOrDefault(x => x.Email == HttpContext.Request.Cookies["email"]);

            if (user == null)
            {   //Create a new user in DB
                UserAccount userAccount = new UserAccount();
                //Set userAccount fields
                userAccount.TimeStamp = DateTime.Now;
                userAccount.Email = HttpContext.Request.Cookies["email"];
                userAccount.PostalCode = "AAA AAA";
                userAccount.FirstName = HttpContext.Request.Cookies["first_name"];
                userAccount.LastName = HttpContext.Request.Cookies["last_name"];

                //Random Password Generation
                Random random = new Random();
                char[] chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789".ToCharArray();
                string password = "";

                for (int i = 0; i < 16; i++)
                {
                    password += chars[random.Next(0, chars.Length)];
                }
                userAccount.Password = password;

                //Code adapted from https://docs.microsoft.com/en-us/aspnet/core/security/data-protection/consumer-apis/password-hashing?view=aspnetcore-5.0

                // generate a 128-bit salt using a secure PRNG
                byte[] salt = new byte[128 / 8];
                using (var rng = RandomNumberGenerator.Create())
                {
                    rng.GetBytes(salt);
                }
                string stringSalt = Convert.ToBase64String(salt);

                // derive a 256-bit subkey (use HMACSHA1 with 10,000 iterations)
                string hashed = Convert.ToBase64String(KeyDerivation.Pbkdf2(
                    password: userAccount.Password,
                    salt: salt,
                    prf: KeyDerivationPrf.HMACSHA1,
                    iterationCount: 10000,
                    numBytesRequested: 256 / 8));


                userAccount.PasswordHash = hashed;
                userAccount.PasswordSalt = stringSalt;

                db.Add(userAccount);
                await db.SaveChangesAsync();
                user = db.UserAccount.FirstOrDefault(x => x.Email == userAccount.Email);
                HttpContext.Response.Cookies.Append("user_id", user.Id.ToString());
                HttpContext.Response.Cookies.Append("first_name", user.FirstName.ToString());
                HttpContext.Response.Cookies.Append("last_name", user.LastName.ToString());
            }
            else
            {   //Login with existing user
                UserLoginLog loginLog = new UserLoginLog();
                loginLog.Id = user.Id;
                loginLog.TimeStamp = DateTime.Now;
                db.Add(loginLog);
                await db.SaveChangesAsync();
                user = db.UserAccount.FirstOrDefault(x => x.Email == HttpContext.Request.Cookies["email"]);
                HttpContext.Response.Cookies.Append("user_id", user.Id.ToString());
                HttpContext.Response.Cookies.Append("first_name", user.FirstName.ToString());
                HttpContext.Response.Cookies.Append("last_name", user.LastName.ToString());
            }
            HttpContext.Response.Cookies.Delete("email");
            return RedirectToAction("index", "Home");
        }

        public IActionResult Logout()
        {
            if (HttpContext.Request.Cookies["user_id"] == null)
                return RedirectToAction("index", "Home");

            HttpContext.Response.Cookies.Delete("user_id");
            HttpContext.Response.Cookies.Delete("first_name");
            HttpContext.Response.Cookies.Delete("last_name");
            return RedirectToAction("index", "Home");
        }

        public IActionResult Reset()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Reset([Bind("Id,Email")] UserAccount user)
        {
            string email = user.Email;
            UserAccount dbUser = GetUserAccountByEmail(user.Email);

            if (dbUser != null)
            {
                // save password in case sending email fails
                string oldPassword = dbUser.Password;

                // create new random string to act as password
                string newPassword = GenerateRandomPassword();

                // return fail result if failed to change password
                if (!SetPassword(dbUser, newPassword))
                {
                    return RedirectToAction(nameof(ResetResult), new ResetResultModel(false, email, "Failed resetting password!"));
                }

                // if failed to send email undo password change return fail result
                if (!SendEmail(dbUser, newPassword))
                {
                    SetPassword(dbUser, oldPassword);
                    return RedirectToAction(nameof(ResetResult), new ResetResultModel(false, email, "Failed sending email!"));
                }

                // return success result
                return RedirectToAction(nameof(ResetResult), new ResetResultModel(true, email));
            }
            else
            {
                return RedirectToAction(nameof(ResetResult), new ResetResultModel(false, email, "Account with email does not exist!"));
            }

            UserAccount GetUserAccountByEmail(string email)
            {
                if (email == null) return null;

                try
                {
                    return (from u in db.UserAccount
                                 where u.Email.ToLower() == email.ToLower()
                                 select new UserAccount
                                 {
                                     Id = u.Id,
                                     Email = u.Email,
                                     FirstName = u.FirstName,
                                     LastName = u.LastName,
                                     Password = u.Password,
                                     PostalCode = u.PostalCode,
                                     TimeStamp = u.TimeStamp
                                 }).ToArray()[0];
                }
                catch (Exception)
                {
                    return null;
                }
            }

            string GenerateRandomPassword()
            {
                const string VALID_CHARACTERS = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
                const int PASSWORD_LENGTH = 16;

                Random random = new Random();

                char[] chars = VALID_CHARACTERS.ToCharArray();
                string password = "";

                for (int i = 0; i < PASSWORD_LENGTH; i++)
                {
                    password += chars[random.Next(0, chars.Length)];
                }

                return password;
            }

            bool SetPassword(UserAccount user, string password)
            {
                try
                {
                    user.Password = password;
                    db.Update(user);
                    db.SaveChanges();

                    return true;
                }
                catch (Exception e)
                {
                    return false;
                }
            }

            bool SendEmail(UserAccount user, string password)
            {
                try
                {
                    var messageObj = new MimeMessage();
                    messageObj.From.Add(new MailboxAddress("Bike Guys", "BikeGuysStore@gmail.com"));
                    messageObj.To.Add(new MailboxAddress("Bike Guys", "BikeGuysStore@gmail.com"));
                    messageObj.To.Add(new MailboxAddress(dbUser.FirstName + " " + dbUser.LastName, dbUser.Email));
                    messageObj.ReplyTo.Add(new MailboxAddress(dbUser.FirstName + " " + dbUser.LastName, dbUser.Email));

                    messageObj.Subject = "Password Reset";
                    messageObj.Body = new TextPart("html")
                    {
                        Text =
                            "<div>" +
                                "<h1>Password Reset!</h1>" +
                                "<p>Your password has been reset!</p>" +
                                string.Format("<p>To login, use the following password: {0}</p>", password) +
                                "<p>Make sure to change it to something new (and don't forget it again)</p>" +
                                "<a href=\"https://thumbs.gfycat.com/BigheartedWebbedAssassinbug-small.gif\"><input type=\"button\" value=\"login\"></a>" +
                            "</div>"
                    };

                    using var client = new SmtpClient();
                    client.Connect("smtp.gmail.com", 587, false);
                    client.Authenticate("BikeGuysStore@gmail.com", "ZBAG2020");
                    client.Send(messageObj);
                    client.Disconnect(true);

                    return true;
                }
                catch (Exception)
                {
                    return false;
                }
            }
        }

        public IActionResult ResetResult(ResetResultModel res)
        {
            return View(res);
        }

        // GET: UserAccounts/Manage/5
        public async Task<IActionResult> Manage(int? id)
        {
            if (id == null || HttpContext.Request.Cookies["user_id"] != id.ToString())
            {
                return NotFound();
            }

            var userAccount = await db.UserAccount.FindAsync(id);
            if (userAccount == null)
            {
                return NotFound();
            }
            return View(userAccount);
        }

        // POST: UserAccounts/Manage/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Manage(int id, [Bind("Id,FirstName,LastName,Email,PostalCode,Password,ConfirmPassword")] UserAccount userAccount)
        {
            if (id != userAccount.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    //Code adapted from https://docs.microsoft.com/en-us/aspnet/core/security/data-protection/consumer-apis/password-hashing?view=aspnetcore-5.0
                    string password = userAccount.Password;

                    // generate a 128-bit salt using a secure PRNG
                    byte[] salt = new byte[128 / 8];
                    using (var rng = RandomNumberGenerator.Create())
                    {
                        rng.GetBytes(salt);
                    }
                    string stringSalt = Convert.ToBase64String(salt);

                    // derive a 256-bit subkey (use HMACSHA1 with 10,000 iterations)
                    string hashed = Convert.ToBase64String(KeyDerivation.Pbkdf2(
                        password: password,
                        salt: salt,
                        prf: KeyDerivationPrf.HMACSHA1,
                        iterationCount: 10000,
                        numBytesRequested: 256 / 8));


                    userAccount.PasswordHash = hashed;
                    userAccount.PasswordSalt = stringSalt;
                    db.Update(userAccount);
                    await db.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!UserAccountExists(userAccount.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                ViewBag.Message = "Credentials successfully updated!";
            }
            return View(userAccount);
        }

        // GET: UserAccounts/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var userAccount = await db.UserAccount
                .FirstOrDefaultAsync(m => m.Id == id);
            if (userAccount == null)
            {
                return NotFound();
            }

            return View(userAccount);
        }

        // POST: UserAccounts/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var userAccount = await db.UserAccount.FindAsync(id);
            db.UserAccount.Remove(userAccount);
            await db.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool UserAccountExists(int id)
        {
            return db.UserAccount.Any(e => e.Id == id);
        }

        private bool SendEmail(UserAccount userAccount)
        {
            bool success = false;

            try
            {
                //Send the email
                var messageObj = new MimeMessage();
                messageObj.From.Add(new MailboxAddress("Bike Guys", "BikeGuysStore@gmail.com"));
                messageObj.To.Add(new MailboxAddress("Bike Guys", "BikeGuysStore@gmail.com"));
                messageObj.To.Add(new MailboxAddress(userAccount.FirstName + " " + userAccount.LastName, userAccount.Email));
                messageObj.ReplyTo.Add(new MailboxAddress(userAccount.FirstName + " " + userAccount.LastName, userAccount.Email));

                messageObj.Subject = "Account Registration Confirmation";
                messageObj.Body = new TextPart("html")
                {
                    Text = "<h1>Hi, " + userAccount.FirstName + "!</h1>" +
                    "<h2>Thank you for registering an account with Bike Guys ®</h2>"
                };

                using var client = new SmtpClient();
                client.Connect("smtp.gmail.com", 587, false);
                client.Authenticate("BikeGuysStore@gmail.com", "ZBAG2020");
                client.Send(messageObj);
                client.Disconnect(true);
                success = true;
            }
            catch (Exception ex)
            {
                success = false;
            }
            return success;
        }
    }
}
