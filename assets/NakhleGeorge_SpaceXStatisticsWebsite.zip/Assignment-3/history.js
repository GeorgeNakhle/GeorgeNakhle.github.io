'use strict'

document.getElementById('historyButton').addEventListener('click', historyEvent);

let value = 1;
function historyEvent()
{
    if (document.getElementById('historyCount').value == "") //1 launch if no input
    {
        document.getElementById('variable').innerHTML = " 1 ";
        value = 1;
    }
    else if (document.getElementById('historyCount').value == "0") //0 launches
    {
        document.getElementById('variable').innerHTML = ` ${document.getElementById('historyCount').value} `;
        const tableBody2 = document.getElementById('historyData');
        tableBody2.innerHTML = ''; //Clear old data
        return;
    }
    else //All other launches
    {
        document.getElementById('variable').innerHTML = ` ${document.getElementById('historyCount').value} `;
        value = document.getElementById('historyCount').value;
    }

    const url2 = `https://api.spacexdata.com/v3/launches/past?limit=${value}`;

    fetch(url2)
    .then(response => response.json())
    .then(data => {
        doStuff(data)
    })
    .catch(function(error) {
        // If there is any error you will catch them here.
        console.log(`ERROR: ${error}`);
    });
}

const url = `https://api.spacexdata.com/v3/launches/past?limit=${value}`; // The root of the SpaceX API

fetch(url)
    .then(response => response.json())
    .then(data => {
        doStuff(data)
    })
    .catch(function(error) {
        // If there is any error you will catch them here.
        console.log(`ERROR: ${error}`);
    });

function doStuff(data) {

    console.log(data);

    const tableBody = document.getElementById('historyData');

    tableBody.innerHTML = ''; //Clear old data

    for (let i = 0; i < data.length; i++)
    {
        const row = document.createElement('tr');
    
        const patchCell = document.createElement('td');
        const nameCell = document.createElement('td');
        const rocketCell = document.createElement('td');
        const dateCell = document.createElement('td');
        const successCell = document.createElement('td');

        const patchImage = new Image();
        patchImage.src = data[i].links.mission_patch_small;
        patchImage.alt = "Patch Image";
        const nameText = document.createTextNode(data[i].mission_name);
        const rocketText = document.createTextNode(data[i].rocket.rocket_name);
        let date = new Date(data[i].launch_date_utc);
        let tempdateText;
        if (date.toString().substr(9,1) == '1')
            tempdateText = document.createTextNode(`${date.toString().substr(4, 6)}st, ${date.toString().substr(10, 5)}`);
        else if (date.toString().substr(9,1) == '2')
            tempdateText = document.createTextNode(`${date.toString().substr(4, 6)}nd, ${date.toString().substr(10, 5)}`);
        else if (date.toString().substr(9,1) == '3')
            tempdateText = document.createTextNode(`${date.toString().substr(4, 6)}rd, ${date.toString().substr(10, 5)}`);
        else
            tempdateText = document.createTextNode(`${date.toString().substr(4, 6)}th, ${date.toString().substr(10, 5)}`);
        const dateText = tempdateText;
        let tempsuccessText;
        if (data[i].launch_success == true)
            tempsuccessText = 'TRUE';
        else
            tempsuccessText = 'FALSE';
        const successText = document.createTextNode(tempsuccessText);

        patchCell.appendChild(patchImage);
        nameCell.appendChild(nameText);
        rocketCell.appendChild(rocketText);
        dateCell.appendChild(dateText);
        successCell.appendChild(successText);
    
        row.appendChild(patchCell);
        row.appendChild(nameCell);
        row.appendChild(rocketCell);
        row.appendChild(dateCell);
        row.appendChild(successCell);
    
        tableBody.appendChild(row);
    }
}