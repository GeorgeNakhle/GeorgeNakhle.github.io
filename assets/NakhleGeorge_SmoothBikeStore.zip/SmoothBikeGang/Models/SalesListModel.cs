﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BikeStore.Models
{
    public class SalesListModel
    {
        public string ProductModel { get; set; }

        public decimal ListPrice { get; set; }

        public decimal DiscountPrice { get; set; }

        public int Discount { get; set; }

        public int ProductModelID { get; set; }

        public int? ParentProductCategoryID { get; set; }
    }
}
