﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using BikeStore.Models;
using Newtonsoft.Json;

namespace BikeStore.Controllers
{
    public class AccessoriesController : Controller
    {
        private readonly AdventureWorksLT2017Context db;

        public AccessoriesController(AdventureWorksLT2017Context context)
        {
            db = context;
        }

        // GET: Accessories
        //public async Task<IActionResult> Index()
        //{
        //    var adventureWorksLT2017Context = db.Product.Include(p => p.ProductCategory).Include(p => p.ProductModel);
        //    return View(await adventureWorksLT2017Context.ToListAsync());
        //}
        public IActionResult Index()
        {
            var accessoryList = from accessory in db.ProductCategory
                                where accessory.ParentProductCategoryId == 4
                                select accessory;

            return View(accessoryList);
        }
        public IActionResult Category(int? category)
        {
            var validAccessories = (from accessory in db.VProductAndDescription
                                   join categories in db.ProductCategory
                                   on new { accessory.ProductCategoryId }
                                   equals new { categories.ProductCategoryId }
                                   join products in db.Product
                                   on new { accessory.ProductId }
                                   equals new { products.ProductId }
                                   where accessory.Culture == "en" &&
                                   accessory.SellEndDate == null &&
                                   accessory.ProductCategoryId == category
                                   select new AccessoryListModel
                                   {   Name = categories.Name,
                                       ProductModel = accessory.ProductModel,
                                       Description = accessory.Description,
                                       ProductModelID = accessory.ProductModelId,
                                       ThumbNailPhoto = products.ThumbNailPhoto
                                   }).Distinct().ToList();

            for(int i = 0; i < validAccessories.Count -1; i++)
            {   if(validAccessories.ElementAt(i).ProductModelID == validAccessories.ElementAt(i + 1).ProductModelID)
                {   validAccessories.RemoveAt(i+1);
                    i--;
                }
            }

            var categoryName = from categories in db.ProductCategory
                                  where categories.ProductCategoryId == category
                                  select categories.Name;
            
            AccessoryListModel title = new AccessoryListModel();

            foreach(var name in categoryName)
                title.Name = name;

            validAccessories.Add(title);

            return View(validAccessories);
        }

        // GET: Accessories/Details/5
        public IActionResult Details(int? id)
        {   if (id == null)
                return NotFound();

            var accessory = from a in db.Product
                           where a.ProductModelId == id && a.SellEndDate == null
                           select a;

            if (accessory == null)
                return NotFound();

            return View(accessory);
        }

        public JsonResult SelectColour(int? id, String colour)
        {
            if (id == null)
            {
                return null;
            }

            var product = (from p in db.Product
                           where p.ProductModelId == id && p.SellEndDate == null
                                && p.Color == colour
                           select p).ToList();

            if (product == null)
            {
                return null;
            }

            var json = JsonConvert.SerializeObject(product);
            return Json(json);
        }

        public JsonResult SelectSize(int? id, String colour, String size)
        {
            if (id == null)
            {
                return null;
            }

            var product = (from p in db.Product
                           where p.ProductModelId == id && p.SellEndDate == null
                                && p.Color == colour && p.Size == size
                           select p).ToList();

            if (product == null)
            {
                return null;
            }

            var json = JsonConvert.SerializeObject(product);
            return Json(json);
        }

        public JsonResult GenerateImage(byte[] image)
        {
            var base64 = Convert.ToBase64String(image);
            var imgsrc = string.Format("data:image/gif;base64,{0}", base64);

            var json = JsonConvert.SerializeObject(imgsrc);
            return Json(json);
        }

        // GET: Accessories/Create
        public IActionResult Create()
        {
            ViewData["ProductCategoryId"] = new SelectList(db.ProductCategory, "ProductCategoryId", "Name");
            ViewData["ProductModelId"] = new SelectList(db.ProductModel, "ProductModelId", "Name");
            return View();
        }

        // POST: Accessories/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("ProductId,Name,ProductNumber,Color,StandardCost,ListPrice,Size,Weight,ProductCategoryId,ProductModelId,SellStartDate,SellEndDate,DiscontinuedDate,ThumbNailPhoto,ThumbnailPhotoFileName,Rowguid,ModifiedDate")] Product product)
        {
            if (ModelState.IsValid)
            {
                db.Add(product);
                await db.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            ViewData["ProductCategoryId"] = new SelectList(db.ProductCategory, "ProductCategoryId", "Name", product.ProductCategoryId);
            ViewData["ProductModelId"] = new SelectList(db.ProductModel, "ProductModelId", "Name", product.ProductModelId);
            return View(product);
        }

        // GET: Accessories/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var product = await db.Product.FindAsync(id);
            if (product == null)
            {
                return NotFound();
            }
            ViewData["ProductCategoryId"] = new SelectList(db.ProductCategory, "ProductCategoryId", "Name", product.ProductCategoryId);
            ViewData["ProductModelId"] = new SelectList(db.ProductModel, "ProductModelId", "Name", product.ProductModelId);
            return View(product);
        }

        // POST: Accessories/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("ProductId,Name,ProductNumber,Color,StandardCost,ListPrice,Size,Weight,ProductCategoryId,ProductModelId,SellStartDate,SellEndDate,DiscontinuedDate,ThumbNailPhoto,ThumbnailPhotoFileName,Rowguid,ModifiedDate")] Product product)
        {
            if (id != product.ProductId)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    db.Update(product);
                    await db.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!ProductExists(product.ProductId))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            ViewData["ProductCategoryId"] = new SelectList(db.ProductCategory, "ProductCategoryId", "Name", product.ProductCategoryId);
            ViewData["ProductModelId"] = new SelectList(db.ProductModel, "ProductModelId", "Name", product.ProductModelId);
            return View(product);
        }

        // GET: Accessories/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var product = await db.Product
                .Include(p => p.ProductCategory)
                .Include(p => p.ProductModel)
                .FirstOrDefaultAsync(m => m.ProductId == id);
            if (product == null)
            {
                return NotFound();
            }

            return View(product);
        }

        // POST: Accessories/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var product = await db.Product.FindAsync(id);
            db.Product.Remove(product);
            await db.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool ProductExists(int id)
        {
            return db.Product.Any(e => e.ProductId == id);
        }
    }
}
