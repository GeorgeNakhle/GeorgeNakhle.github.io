'use strict'

document.getElementById('Falcon1').addEventListener('click', F1event);
document.getElementById('Falcon9').addEventListener('click', F9event);
document.getElementById('FalconHeavy').addEventListener('click', FHevent);
document.getElementById('Starship').addEventListener('click', Sevent);

function F1event()
{
    const url1 = `https://api.spacexdata.com/v3/rockets/falcon1`;

    fetch(url1)
    .then(response => response.json())
    .then(data => {
        doStuff(data)
    })
    .catch(function(error) {
        // If there is any error you will catch them here.
        console.log(`ERROR: ${error}`);
    });
}

function F9event()
{
    const url2 = `https://api.spacexdata.com/v3/rockets/falcon9`;

    fetch(url2)
    .then(response => response.json())
    .then(data => {
        doStuff(data)
    })
    .catch(function(error) {
        // If there is any error you will catch them here.
        console.log(`ERROR: ${error}`);
    });
}

function FHevent()
{
    const url3 = `https://api.spacexdata.com/v3/rockets/falconheavy`;

    fetch(url3)
    .then(response => response.json())
    .then(data => {
        doStuff(data)
    })
    .catch(function(error) {
        // If there is any error you will catch them here.
        console.log(`ERROR: ${error}`);
    });
}

function Sevent()
{
    const url4 = `https://api.spacexdata.com/v3/rockets/starship`;

    fetch(url4)
    .then(response => response.json())
    .then(data => {
        doStuff(data)
    })
    .catch(function(error) {
        // If there is any error you will catch them here.
        console.log(`ERROR: ${error}`);
    });
}

const url = `https://api.spacexdata.com/v3/rockets/falcon1`; // The root of the SpaceX API

fetch(url)
    .then(response => response.json())
    .then(data => {
        doStuff(data)
    })
    .catch(function(error) {
        // If there is any error you will catch them here.
        console.log(`ERROR: ${error}`);
    });

function doStuff(data) {

    console.log(data);
    

    const rocketnameSlot = document.getElementById('rocketName');
    const costSlot = document.getElementById('cost');
    const heightmetersSlot = document.getElementById('heightMeters');
    const descriptionSlot = document.getElementById('description');

    const rocketnameText = document.createTextNode(data.rocket_name);
    const costText = document.createTextNode(`$${data.cost_per_launch.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")}`);
    const heightmetersText = document.createTextNode(`${data.height.meters}m`);
    const descriptionText = document.createTextNode(data.description)

    rocketnameSlot.innerHTML = "";
    costSlot.innerHTML = "";
    heightmetersSlot.innerHTML = "";
    descriptionSlot.innerHTML = "";

    rocketnameSlot.appendChild(rocketnameText);
    costSlot.appendChild(costText);
    heightmetersSlot.appendChild(heightmetersText);
    descriptionSlot.appendChild(descriptionText);
}