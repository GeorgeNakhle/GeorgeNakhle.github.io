﻿using System.ComponentModel.DataAnnotations;

namespace BikeStore.Models
{
    public class SearchField
    {
        [Required]
        public string Field { get; set; }
    }
}
