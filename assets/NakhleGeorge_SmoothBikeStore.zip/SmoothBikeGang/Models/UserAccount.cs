﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace BikeStore.Models
{
    public class UserAccount
    {
        [Key]
        public int Id { get; set; }

        [Required]
        public DateTime TimeStamp { get; set; }

        [Required]
        [Display(Name = "First Name")]
        [StringLength(100, ErrorMessage = "Must be between 2 and 100 characters", MinimumLength = 2)]
        public string FirstName { get; set; }

        [Required]
        [Display(Name = "Last Name")]
        [StringLength(100, ErrorMessage = "Must be between 2 and 100 characters", MinimumLength = 2)]
        public string LastName { get; set; }

        [Required]
        [DataType(DataType.EmailAddress)]
        [RegularExpression(@".*@.*\.\w{2,}", ErrorMessage = "Invalid email address")]
        public string Email { get; set; }

        [Required]
        [Display(Name = "Postal Code")]
        [RegularExpression(@"^\d{​​5}​​-\d{​​4}​​|\d{​​5}​​|[A-Z]\d[A-Z] \d[A-Z]\d$", ErrorMessage = "Invalid postal code")]
        public string PostalCode { get; set; }

        [Required]
        [DataType(DataType.Password)]
        [StringLength(255, ErrorMessage = "Must be between 5 and 255 characters", MinimumLength = 5)]
        [NotMapped]
        public string Password { get; set; }

        public string PasswordHash { get; set; }

        public string PasswordSalt { get; set; }

        [Required]
        [Display(Name = "Confirm Password")]
        [DataType(DataType.Password)]
        [Compare("Password", ErrorMessage = "The fields Password and Confirm Password should be equals")]
        [NotMapped]
        public string ConfirmPassword { get; set; }
    }
}
