﻿namespace BikeStore.Models
{
    public class SearchProduct
    {
        // stuff for logic, but not searched on
        public int ProductID { get; set; }
        public int ProductCategoryID { get; set; }
        public int ProductModelID { get; set; }

        // stuff to search terms in
        public string ProductName { get; set; }
        public string ProductNumber { get; set; }
        public string CategoryName { get; set; }
        public string ParentCategoryName { get; set; }
        public string ModelName { get; set; }
        public string Description { get; set; }
        public string Color { get; set; }

        public int Relevancy { get; set; }

        public void CalculateRelevancy(string[] terms)
        {
            Relevancy = 0;

            foreach (string value in GetDisplayValues())
            {
                foreach (string term in terms)
                {
                    if (value == null) continue;

                    if (value.ToLower().Contains(term.ToLower())) Relevancy++;
                }
            }
        }

        public string[] GetDisplayValues()
        {
            return new string[] { ProductName, ProductNumber, CategoryName, ParentCategoryName, ModelName, Description, Color };
    }
    }
}
