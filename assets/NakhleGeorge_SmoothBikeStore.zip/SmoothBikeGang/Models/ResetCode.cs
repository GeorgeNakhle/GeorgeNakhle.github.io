﻿using System;
using System.ComponentModel.DataAnnotations;

namespace BikeStore.Models
{
    public class ResetCode
    {
        [Key]
        public int Id { get; set; }

        [Required]
        public int Code { get; set; }

        [Required]
        public DateTime CreationDate { get; set; } = DateTime.Now;

        [Required]
        public DateTime ExpirationDate { get; set; } = DateTime.Now.AddDays(1);

        [Required]
        public bool WasUsed { get; set; } = false;
    }
}
