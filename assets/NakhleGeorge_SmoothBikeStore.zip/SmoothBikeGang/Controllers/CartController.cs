﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using BikeStore.Models;

namespace BikeStore.Views
{
    public class CartController : Controller
    {
        private readonly AdventureWorksLT2017Context db;

        public CartController(AdventureWorksLT2017Context context)
        {
            db = context;
        }

        // GET: Cart
        public IActionResult Index()
        {
            if (HttpContext.Request.Cookies["user_id"] == null)
                return View("/Views/UserAccounts/Login.cshtml");

            int id = int.Parse(HttpContext.Request.Cookies["user_id"]);
            //int id = 1;

            var cart = QueryCart(id);
            return View("Details", cart);
        }

        // GET: Cart/Details/5
        public IActionResult Details()
        {
            if (HttpContext.Request.Cookies["user_id"] == null)
                return View("/Views/UserAccounts/Login.cshtml");

            int id = int.Parse(HttpContext.Request.Cookies["user_id"]);
            //int id = 1;

            var cart = QueryCart(id);

            if (cart == null)
            {
                return NotFound();
            }

            return View(cart);
        }

        public List<CartListModel> QueryCart(int id)
        {   var cart = (from cartItems in db.Cart
                        join products in db.Product
                        on cartItems.ProductId equals products.ProductId
                        join categories in db.ProductCategory
                        on products.ProductCategoryId
                        equals categories.ProductCategoryId
                        where cartItems.UserId == id 
                        select new CartListModel
                        {   ProductId = cartItems.ProductId,
                            ProductCategory = categories.Name,
                            ProductName = products.Name,
                            ProductCost = products.ListPrice,
                            Quantity = cartItems.Quantity,
                            ThumbNailPhoto = products.ThumbNailPhoto
                        }
                          ).Distinct().ToList();
            return cart;
        }

        // POST: Cart/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("ProductId,Quantity")] Cart purchase)
        {   if (HttpContext.Request.Cookies["user_id"] == null)
                return View("/Views/UserAccounts/Login.cshtml");
            if (purchase.Quantity < 1)
                return RedirectToAction("Index");
            int id = int.Parse(HttpContext.Request.Cookies["user_id"]);
            purchase.UserId = id;
            //If the user already has purchased the product, increase the product's quantity for the user.
            if(ModelState.IsValid && CheckCart(purchase))
            {   //Get and add to the quantity then go to cart.
                int quantityNew = GetQuantity(purchase);
                quantityNew += purchase.Quantity;
                purchase.Quantity = quantityNew;
                return RedirectToAction(nameof(Edit), purchase);
            }
            else if (ModelState.IsValid)
            {   db.Add(purchase);
                await db.SaveChangesAsync();
                List<CartListModel> cart = QueryCart(id);
                return RedirectToAction("Index", cart);
            }
            return View("");
        }

        public int GetQuantity(Cart purchase)
        {   //Get the quantity of  the user's product already in the database.
            var quantity = from product in db.Cart
                           where product.ProductId == purchase.ProductId && product.UserId == purchase.UserId
                           select product.Quantity;
            int current = 0;
            foreach (int values in quantity)
                current = values;
            return current;
        }

        public bool CheckCart(Cart purchase)
        {   var quantity = from product in db.Cart
                           where product.ProductId == purchase.ProductId && product.UserId == purchase.UserId
                           select product;
            var item = -1;
            foreach (var val in quantity)
                item = val.Quantity;
            //If the user already has purchased the product, increase the product's quantity for the user.
            if (item != -1)
                return true;
            return false;
        }

        // GET: Cart/Edit/5
        public async Task<IActionResult> Edit(Cart purchase)
        {
            db.Update(purchase);
            await db.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
            //if (id == null)
            //{
            //    return NotFound();
            //}

            //var cart = await db.Cart.FindAsync(id);
            //if (cart == null)
            //{
            //    return NotFound();
            //}
            //return View(cart);
        }

        // POST: Cart/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("UserId,ProductId,Quantity")] Cart cart)
        {
            if (id != cart.UserId)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    db.Update(cart);
                    await db.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!CartExists(cart.UserId))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(cart);
        }

        // GET: Cart/Delete/5
        public async Task<IActionResult> Delete(int? productId)
        {
            if (productId == null)
            {
                return NotFound();
            }

            if (HttpContext.Request.Cookies["user_id"] == null)
                return NotFound();
            int userId = int.Parse(HttpContext.Request.Cookies["user_id"]);

            var cart = from product in db.Cart
                       where product.ProductId == productId && product.UserId == userId
                       select product;
            Cart item = null;
            foreach (Cart purchase in cart)
                item = purchase;
            if (cart == null)
            {
                return NotFound();
            }

            db.Cart.Remove(item);
            await db.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        // POST: Cart/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int productId)
        {   if (HttpContext.Request.Cookies["user_id"] == null)
                return NotFound();
            int userId = int.Parse(HttpContext.Request.Cookies["user_id"]);
            var purchases = from product in db.Cart
                       where product.ProductId == productId && product.UserId == userId
                       select product;
            Cart current = null;
            foreach (Cart purchase in purchases)
                current = purchase;
            if (current == null)
                return NotFound();
            db.Cart.Remove(current);
            await db.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool CartExists(int id)
        {
            return db.Cart.Any(e => e.UserId == id);
        }
    }
}
