﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using BikeStore.Models;
using Newtonsoft.Json;

namespace BikeStore.Controllers
{
    public class ComponentsController : Controller
    {
        private readonly AdventureWorksLT2017Context db;

        public ComponentsController(AdventureWorksLT2017Context context)
        {
            db = context;
        }

        // GET: Components
        //public async Task<IActionResult> Index()
        //{
        //    var adventureWorksLT2017Context = db.ProductCategory.Include(p => p.ParentProductCategory);
        //    return View(await adventureWorksLT2017Context.ToListAsync());
        //}

        public IActionResult Index()
        {   var componentList = from components in db.ProductCategory
                           where components.ParentProductCategoryId == 2
                           select components;

            return View(componentList);
        }

        public IActionResult Category(int? category)
        {
            var validComponents = (from components in db.VProductAndDescription
                                    join categories in db.ProductCategory
                                    on new { components.ProductCategoryId }
                                    equals new { categories.ProductCategoryId }
                                    join products in db.Product
                                    on new { components.ProductId }
                                    equals new { products.ProductId }
                                    where components.Culture == "en" &&
                                    components.SellEndDate == null &&
                                    components.ProductCategoryId == category
                                    select new ComponentListModel
                                    {   Name = categories.Name,
                                        ProductModel = components.ProductModel,
                                        Description = components.Description,
                                        ProductModelID = components.ProductModelId,
                                        ThumbNailPhoto = products.ThumbNailPhoto
                                    }).Distinct().ToList();

            for(int i = 0; i < validComponents.Count -1; i++)
            {   if(validComponents.ElementAt(i).ProductModelID == validComponents.ElementAt(i + 1).ProductModelID)
                {   validComponents.RemoveAt(i+1);
                    i--;
                }
            }

            var categoryName = from categories in db.ProductCategory
                               where categories.ProductCategoryId == category
                               select categories.Name;

            ComponentListModel title = new ComponentListModel();

            foreach (var name in categoryName)
                title.Name = name;

            validComponents.Add(title);

            return View(validComponents);
        }

        //Get a list of component items
        //public  IEnumerable CategoryList()
        //{
        //    return  (from components in db.VProductAndDescription
        //                              join categories in db.ProductCategory
        //                              on new { components.ProductCategoryId }
        //                              equals new { categories.ProductCategoryId }
        //                              where components.Culture == "en" &&
        //                              components.SellEndDate == null &&
        //                              components.ProductCategoryId == category
        //                              select new AccessoryListModel
        //                              {
        //                                  Name = categories.Name,
        //                                  ProductModel = components.ProductModel,
        //                                  Description = components.Description,
        //                                  ProductModelID = components.ProductModelId
        //                              }).Distinct().ToList();
        //}

        // GET: Components/Details/5
        public IActionResult Details(int? id)
        {
            if (id == null)
                return NotFound();

            //var productCategory = await db.ProductCategory
            //    .Include(p => p.ParentProductCategory)
            //    .FirstOrDefaultAsync(m => m.ProductCategoryId == id);

            var component = from c in db.Product
                           where c.ProductModelId == id && c.SellEndDate == null
                           select c;

            if (component == null)
                return NotFound();

            return View(component);
        }

        public JsonResult SelectColour(int? id, String colour)
        {
            if (id == null)
            {
                return null;
            }

            var product = (from p in db.Product
                           where p.ProductModelId == id && p.SellEndDate == null
                                && p.Color == colour
                           select p).ToList();

            if (product == null)
            {
                return null;
            }

            var json = JsonConvert.SerializeObject(product);
            return Json(json);
        }

        public JsonResult SelectSize(int? id, String colour, String size)
        {
            if (id == null)
            {
                return null;
            }

            var product = (from p in db.Product
                           where p.ProductModelId == id && p.SellEndDate == null
                                && p.Color == colour && p.Size == size
                           select p).ToList();

            if (product == null)
            {
                return null;
            }

            var json = JsonConvert.SerializeObject(product);
            return Json(json);
        }

        public JsonResult GenerateImage(byte[] image)
        {
            var base64 = Convert.ToBase64String(image);
            var imgsrc = string.Format("data:image/gif;base64,{0}", base64);

            var json = JsonConvert.SerializeObject(imgsrc);
            return Json(json);
        }

        // GET: Components/Create
        public IActionResult Create()
        {
            ViewData["ParentProductCategoryId"] = new SelectList(db.ProductCategory, "ProductCategoryId", "Name");
            return View();
        }

        // POST: Components/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("ProductCategoryId,ParentProductCategoryId,Name,Rowguid,ModifiedDate")] ProductCategory productCategory)
        {
            if (ModelState.IsValid)
            {
                db.Add(productCategory);
                await db.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            ViewData["ParentProductCategoryId"] = new SelectList(db.ProductCategory, "ProductCategoryId", "Name", productCategory.ParentProductCategoryId);
            return View(productCategory);
        }

        // GET: Components/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var productCategory = await db.ProductCategory.FindAsync(id);
            if (productCategory == null)
            {
                return NotFound();
            }
            ViewData["ParentProductCategoryId"] = new SelectList(db.ProductCategory, "ProductCategoryId", "Name", productCategory.ParentProductCategoryId);
            return View(productCategory);
        }

        // POST: Components/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("ProductCategoryId,ParentProductCategoryId,Name,Rowguid,ModifiedDate")] ProductCategory productCategory)
        {
            if (id != productCategory.ProductCategoryId)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    db.Update(productCategory);
                    await db.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!ProductCategoryExists(productCategory.ProductCategoryId))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            ViewData["ParentProductCategoryId"] = new SelectList(db.ProductCategory, "ProductCategoryId", "Name", productCategory.ParentProductCategoryId);
            return View(productCategory);
        }

        // GET: Components/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var productCategory = await db.ProductCategory
                .Include(p => p.ParentProductCategory)
                .FirstOrDefaultAsync(m => m.ProductCategoryId == id);
            if (productCategory == null)
            {
                return NotFound();
            }

            return View(productCategory);
        }

        // POST: Components/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var productCategory = await db.ProductCategory.FindAsync(id);
            db.ProductCategory.Remove(productCategory);
            await db.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool ProductCategoryExists(int id)
        {
            return db.ProductCategory.Any(e => e.ProductCategoryId == id);
        }
    }
}
