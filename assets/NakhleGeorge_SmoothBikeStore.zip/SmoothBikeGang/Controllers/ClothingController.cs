﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using BikeStore.Models;
using Newtonsoft.Json;

namespace BikeStore.Controllers
{
    public class ClothingController : Controller
    {
        private readonly AdventureWorksLT2017Context db;

        public ClothingController(AdventureWorksLT2017Context context)
        {
            db = context;
        }

        // GET: Clothing
        //public async Task<IActionResult> Index()
        //{
        //    return View(await db.ProductModel.ToListAsync());
        //}
        public IActionResult Index()
        {   var clothingList = from clothing in db.ProductCategory
                               where clothing.ParentProductCategoryId == 3
                               select clothing;

            return View(clothingList);
        }

        public IActionResult Category(int? category)
        {   var validClothing = (from clothing in db.VProductAndDescription
                                  join categories in db.ProductCategory
                                  on new { clothing.ProductCategoryId }
                                  equals new { categories.ProductCategoryId }
                                  join products in db.Product
                                  on new { clothing.ProductId }
                                  equals new { products.ProductId }
                                  where clothing.Culture == "en" &&
                                  clothing.SellEndDate == null &&
                                  clothing.ProductCategoryId == category
                                  select new ClothingListModel
                                  { Name = categories.Name,
                                    ProductModel = clothing.ProductModel,
                                    Description = clothing.Description,
                                    ProductModelID = clothing.ProductModelId,
                                    ThumbNailPhoto = products.ThumbNailPhoto
                                  }).Distinct().ToList();

            for(int i = 0; i < validClothing.Count -1; i++)
            {   if(validClothing.ElementAt(i).ProductModelID == validClothing.ElementAt(i + 1).ProductModelID)
                {   validClothing.RemoveAt(i+1);
                    i--;
                }
            }

            var categoryName = from categories in db.ProductCategory
                               where categories.ProductCategoryId == category
                               select categories.Name;

            ClothingListModel title = new ClothingListModel();

            foreach (var name in categoryName)
                title.Name = name;

            validClothing.Add(title);

            return View(validClothing);
        }

        // GET: Clothing/Details/5
        public IActionResult Details(int? id)
        {   if (id == null)
                return NotFound();

            var clothing = from c in db.Product
                            where c.ProductModelId == id && c.SellEndDate == null
                            select c;

            if (clothing == null)
                return NotFound();

            return View(clothing);
        }

        public JsonResult SelectColour(int? id, String colour)
        {
            if (id == null)
            {
                return null;
            }

            var product = (from p in db.Product
                           where p.ProductModelId == id && p.SellEndDate == null
                                && p.Color == colour
                           select p).ToList();

            if (product == null)
            {
                return null;
            }

            var json = JsonConvert.SerializeObject(product);
            return Json(json);
        }

        public JsonResult SelectSize(int? id, String colour, String size)
        {
            if (id == null)
            {
                return null;
            }

            var product = (from p in db.Product
                           where p.ProductModelId == id && p.SellEndDate == null
                                && p.Color == colour && p.Size == size
                           select p).ToList();

            if (product == null)
            {
                return null;
            }

            var json = JsonConvert.SerializeObject(product);
            return Json(json);
        }

        public JsonResult GenerateImage(byte[] image)
        {
            var base64 = Convert.ToBase64String(image);
            var imgsrc = string.Format("data:image/gif;base64,{0}", base64);

            var json = JsonConvert.SerializeObject(imgsrc);
            return Json(json);
        }

        // GET: Clothing/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: Clothing/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("ProductModelId,Name,CatalogDescription,Rowguid,ModifiedDate")] ProductModel productModel)
        {
            if (ModelState.IsValid)
            {
                db.Add(productModel);
                await db.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(productModel);
        }

        // GET: Clothing/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var productModel = await db.ProductModel.FindAsync(id);
            if (productModel == null)
            {
                return NotFound();
            }
            return View(productModel);
        }

        // POST: Clothing/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("ProductModelId,Name,CatalogDescription,Rowguid,ModifiedDate")] ProductModel productModel)
        {
            if (id != productModel.ProductModelId)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    db.Update(productModel);
                    await db.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!ProductModelExists(productModel.ProductModelId))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(productModel);
        }

        // GET: Clothing/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var productModel = await db.ProductModel
                .FirstOrDefaultAsync(m => m.ProductModelId == id);
            if (productModel == null)
            {
                return NotFound();
            }

            return View(productModel);
        }

        // POST: Clothing/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var productModel = await db.ProductModel.FindAsync(id);
            db.ProductModel.Remove(productModel);
            await db.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool ProductModelExists(int id)
        {
            return db.ProductModel.Any(e => e.ProductModelId == id);
        }
    }
}
