﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using BikeStore.Models;

namespace BikeStore.Controllers
{
    public class HomeController : Controller
    {
        private readonly AdventureWorksLT2017Context db;
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger, AdventureWorksLT2017Context context)
        {
            _logger = logger;
            db = context;
        }

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Careers()
        {
            return View();
        }

        public IActionResult AboutUs()
        {
            return View();
        }

        public IActionResult CyclingSafety()
        {
            return View();
        }

        public IActionResult ReturnsPolicy()
        {
            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        public IActionResult Services()
        {
            return View();
        }

        
        public IActionResult Search(string field)
        {
            List<SearchProduct> products = new List<SearchProduct>();

            if (field == null) return View(products);

            products = GetProductList();
            products = GetRelevantProducts(products, field.Split(' '));
            products = GetSortedProductListByRelevance(products);

            return View(products);


            /*
             public int ProductID { get; set; }
            public int ProductCategoryID { get; set; }
            public int ProductModelID { get; set; }

            // stuff to search terms in
            public string ProductName { get; set; }
            public string ProductNumber { get; set; }
            public string CategoryName { get; set; }
            public string ModelName { get; set; }
            public string Description { get; set; }
            public string Color { get; set; }
             */

            List<SearchProduct> GetProductList()
            {
                return (from p in db.Product
                    join c in db.ProductCategory on p.ProductCategoryId equals c.ProductCategoryId
                    join m in db.ProductModel on p.ProductModelId equals m.ProductModelId
                    join md in db.ProductModelProductDescription on m.ProductModelId equals md.ProductModelId
                    join d in db.ProductDescription on md.ProductDescriptionId equals d.ProductDescriptionId
                    join pc in db.ProductCategory on c.ParentProductCategoryId equals pc.ProductCategoryId
                    where p.SellEndDate == null && md.Culture == "en"
                    select new SearchProduct
                    {
                        ProductID = p.ProductId,
                        ProductCategoryID = c.ProductCategoryId,
                        ProductModelID = m.ProductModelId,
                        ProductName = p.Name,
                        ProductNumber = p.ProductNumber,
                        CategoryName = c.Name,
                        ParentCategoryName = pc.Name,
                        ModelName = m.Name,
                        Description = d.Description,
                        Color = p.Color
                    }).ToList();
            }

            List<SearchProduct> GetRelevantProducts(List<SearchProduct> prods, string[] terms)
            {
                List<SearchProduct> relevantProducts = new List<SearchProduct>();
                foreach (SearchProduct prod in prods)
                {
                    prod.CalculateRelevancy(terms);
                    if (prod.Relevancy > 0) relevantProducts.Add(prod);
                }
                return relevantProducts;
            }

            List<SearchProduct> GetSortedProductListByRelevance(List<SearchProduct> prods)
            {
                return prods.OrderBy(prod => prod.Relevancy).Reverse().ToList();
            }
        }

        public IActionResult Sales()
        {
            /*
            SELECT DISTINCT PAD.ProductModel,
	            P.ListPrice,
	            ROUND((P.ListPrice-(P.ListPrice * SOD.UnitPriceDiscount)), 2) AS DiscountPrice,
	            CAST(SOD.UnitPriceDiscount * 100 AS INT) AS Discount,
	            PAD.ProductModelID,
	            PC.ParentProductCategoryID
            FROM Saleslt.Product AS P
            INNER JOIN Saleslt.SalesOrderDetail AS SOD
	            ON P.ProductID = SOD.ProductID
            INNER JOIN Saleslt.vProductAndDescription AS PAD
	            ON P.ProductModelID = PAD.ProductModelID
            INNER JOIN Saleslt.ProductCategory AS PC
	            ON P.ProductCategoryID = PC.ProductCategoryID
            WHERE SOD.UnitPriceDiscount > 0 AND P.SellEndDate IS NULL
            ORDER BY Discount DESC
            */

            var validSalesProducts =    (from product in db.Product
                                        join sales in db.SalesOrderDetail
                                            on product.ProductId equals sales.ProductId
                                        join productDescription in db.VProductAndDescription
                                            on product.ProductModelId equals productDescription.ProductModelId
                                        join category in db.ProductCategory
                                            on product.ProductCategoryId equals category.ProductCategoryId
                                        where sales.UnitPriceDiscount > 0 &&
                                        product.SellEndDate == null
                                        orderby (int)(sales.UnitPriceDiscount * 100) descending
                                        select new SalesListModel
                                        {
                                            ProductModel = productDescription.ProductModel,
                                            ListPrice = product.ListPrice,
                                            DiscountPrice = Math.Round((product.ListPrice-(product.ListPrice * sales.UnitPriceDiscount)), 2),
                                            Discount = (int)(sales.UnitPriceDiscount * 100),
                                            ProductModelID = productDescription.ProductModelId,
                                            ParentProductCategoryID = category.ParentProductCategoryId
                                        }).Distinct().ToList();
                                      

            return View(validSalesProducts);
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
