﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BikeStore.Models
{
    public class ComponentListModel
    {
        public string Name { get; set; }

        public string ProductModel { get; set; }

        public string Description { get; set; }

        public int ProductModelID { get; set; }
        public byte[] ThumbNailPhoto { get; set; }
    }
}
