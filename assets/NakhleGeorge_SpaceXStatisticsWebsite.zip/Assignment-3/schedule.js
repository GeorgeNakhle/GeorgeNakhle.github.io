'use strict'

const url = `https://api.spacexdata.com/v3/launches/next`; // The root of the SpaceX API

fetch(url)
    .then(response => response.json())
    .then(data => {
        doStuff(data)
    })
    .catch(function(error) {
        // If there is any error you will catch them here.
        console.log(`ERROR: ${error}`);
    });

function doStuff(data) {

    console.log(data);

    const flightnumberSlot = document.getElementById('flightNum');
    const rocketnameSlot = document.getElementById('rocketName');
    const missionnameSlot = document.getElementById('missionName');
    const locationSlot = document.getElementById('launchLocation');
    const dateSlot = document.getElementById('launchDate');
    const timeSlot = document.getElementById('launchTime');

    const flightnumberText = document.createTextNode(`#${data.flight_number}`);
    const rocketnameText = document.createTextNode(data.rocket.rocket_name);
    const missionnameText = document.createTextNode(data.mission_name);
    const locationText = document.createTextNode(data.launch_site.site_name_long);

    let date = new Date(data.launch_date_utc);
    let tempdateText;
    if (date.toString().substr(9,1) == '1')
        tempdateText = document.createTextNode(`${date.toString().substr(4, 6)}st, ${date.toString().substr(10, 5)}`);
    else if (date.toString().substr(9,1) == '2')
        tempdateText = document.createTextNode(`${date.toString().substr(4, 6)}nd, ${date.toString().substr(10, 5)}`);
    else if (date.toString().substr(9,1) == '3')
        tempdateText = document.createTextNode(`${date.toString().substr(4, 6)}rd, ${date.toString().substr(10, 5)}`);
    else
        tempdateText = document.createTextNode(`${date.toString().substr(4, 6)}th, ${date.toString().substr(10, 5)}`);
    const dateText = tempdateText;

    date = new Date(data.launch_date_unix*1000);
    let hours = date.getHours();
    let minutes = "0" + date.getMinutes();
    let seconds = "0" + date.getSeconds();
    let formattedTime = hours + ':' + minutes.substr(-2) + ':' + seconds.substr(-2);
    const timeText = document.createTextNode(formattedTime);

    flightnumberSlot.appendChild(flightnumberText);
    rocketnameSlot.appendChild(rocketnameText);
    missionnameSlot.appendChild(missionnameText);
    locationSlot.appendChild(locationText);
    dateSlot.appendChild(dateText);
    timeSlot.appendChild(timeText);
}