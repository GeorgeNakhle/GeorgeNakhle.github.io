﻿using BikeStore.Controllers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BikeStore.Models
{
    public class NavigationItem
    {
        public string controllerName { get; set; }
        public string actionName { get; set; }
        public string displayName { get; set; }
        public bool hasOnHover { get; set; } = false;
        public NavigationItem[] onHover { get; set; }

 
        public static void prepNavigation()
        {
        }

        public int? id { get; set; }
        public static NavigationItem[] HeaderNavigationItems = new NavigationItem[]   //might split into top and bottom navigation
        {
            new NavigationItem{ controllerName="Bikes", actionName="Index", displayName="Bikes", hasOnHover=true,
                onHover= new NavigationItem[]{
                    new NavigationItem{ controllerName="Bikes", actionName="Road", displayName="Road" },
                    new NavigationItem{ controllerName="Bikes", actionName="Mountain", displayName="Mountain" },
                    new NavigationItem{ controllerName="Bikes", actionName="Touring", displayName="Touring" }
                }},
            new NavigationItem{ controllerName="Components", actionName="Index", displayName="Components", hasOnHover=true,
                onHover= new NavigationItem[]
                {
                    new NavigationItem{ controllerName="Components", actionName="Category", displayName="Handlebars", id=8 },
                    new NavigationItem{ controllerName="Components", actionName="Category", displayName="Bottom Brackets", id=9 },
                    new NavigationItem{ controllerName="Components", actionName="Category", displayName="Brakes", id=10 },
                    new NavigationItem{ controllerName="Components", actionName="Category", displayName="Chains", id=11 },
                    new NavigationItem{ controllerName="Components", actionName="Category", displayName="Cranksets", id=12 },
                    new NavigationItem{ controllerName="Components", actionName="Category", displayName="Deraileurs", id=13 },
                    new NavigationItem{ controllerName="Components", actionName="Category", displayName="Forks", id=14 },
                    new NavigationItem{ controllerName="Components", actionName="Category", displayName="Headsets", id=15 },
                    new NavigationItem{ controllerName="Components", actionName="Category", displayName="Mountain Frames", id=16 },
                    new NavigationItem{ controllerName="Components", actionName="Category", displayName="Pedals", id=17 },
                    new NavigationItem{ controllerName="Components", actionName="Category", displayName="Road Frames", id=18 },
                    new NavigationItem{ controllerName="Components", actionName="Category", displayName="Saddles", id=19 },
                    new NavigationItem{ controllerName="Components", actionName="Category", displayName="Touring Frames", id=20 },
                    new NavigationItem{ controllerName="Components", actionName="Category", displayName="Wheels", id=21 }
                }},
            new NavigationItem{ controllerName="Clothing", actionName="Index", displayName="Clothing", hasOnHover=true,
                onHover= new NavigationItem[]
                {
                    new NavigationItem{ controllerName="Clothing", actionName="Category", displayName="Bib-Shorts", id=22 },
                    new NavigationItem{ controllerName="Clothing", actionName="Category", displayName="Caps", id=23 },
                    new NavigationItem{ controllerName="Clothing", actionName="Category", displayName="Gloves", id=24 },
                    new NavigationItem{ controllerName="Clothing", actionName="Category", displayName="Jerseys", id=25 },
                    new NavigationItem{ controllerName="Clothing", actionName="Category", displayName="Shorts", id=26 },
                    new NavigationItem{ controllerName="Clothing", actionName="Category", displayName="Socks", id=27 },
                    new NavigationItem{ controllerName="Clothing", actionName="Category", displayName="Tights", id=28 },
                    new NavigationItem{ controllerName="Clothing", actionName="Category", displayName="Vests", id=29 },
                }},
            new NavigationItem{ controllerName="Accessories", actionName="Index", displayName="Accessories", hasOnHover=true,
                onHover= new NavigationItem[]
                {
                    new NavigationItem{ controllerName="Accessories", actionName="Category", displayName="Bike-Racks", id=30 },
                    new NavigationItem{ controllerName="Accessories", actionName="Category", displayName="Bike-Stands", id=31 },
                    new NavigationItem{ controllerName="Accessories", actionName="Category", displayName="Bottles and Cages", id=32 },
                    new NavigationItem{ controllerName="Accessories", actionName="Category", displayName="Cleaners", id=33 },
                    new NavigationItem{ controllerName="Accessories", actionName="Category", displayName="Fenders", id=34 },
                    new NavigationItem{ controllerName="Accessories", actionName="Category", displayName="Helmets", id=35 },
                    new NavigationItem{ controllerName="Accessories", actionName="Category", displayName="Hydration Packs", id=36 },
                    new NavigationItem{ controllerName="Accessories", actionName="Category", displayName="Lights", id=37 },
                    new NavigationItem{ controllerName="Accessories", actionName="Category", displayName="Locks", id=38 },
                    new NavigationItem{ controllerName="Accessories", actionName="Category", displayName="Panniers", id=39 },
                    new NavigationItem{ controllerName="Accessories", actionName="Category", displayName="Pumps", id=40 },
                    new NavigationItem{ controllerName="Accessories", actionName="Category", displayName="Tires and Tubes", id=41 },

                }},
            new NavigationItem{controllerName="Home", actionName="Services", displayName="Services"}
        };

        public static NavigationItem[] FooterNavigationItems = new NavigationItem[]   //might split into top and bottom navigation
        {
            new NavigationItem{ controllerName="Bikes", actionName="Index", displayName="Bikes" },
            new NavigationItem{ controllerName="Components", actionName="Index", displayName="Components" },
            new NavigationItem{ controllerName="Clothing", actionName="Index", displayName="Clothing"},
            new NavigationItem{ controllerName="Accessories", actionName="Index", displayName="Accessories"},
            new NavigationItem{ controllerName="Home", actionName="AboutUs", displayName="About Us" },
            new NavigationItem{ controllerName="ContactUs", actionName="Index", displayName="Contact Us"},
            new NavigationItem{ controllerName="Home", actionName="Careers", displayName="Careers" },
            new NavigationItem{ controllerName="Home", actionName="CyclingSafety", displayName="Cycling Safety" },
            new NavigationItem{ controllerName="Home", actionName="ReturnsPolicy", displayName="Return Policy" }
        };
    }
}
