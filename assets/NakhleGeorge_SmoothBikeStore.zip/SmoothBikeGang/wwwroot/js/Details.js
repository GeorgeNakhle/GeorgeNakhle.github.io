﻿// Please see documentation at https://docs.microsoft.com/aspnet/core/client-side/bundling-and-minification
// for details on configuring this project to bundle and minify static web assets.

// Write your JavaScript code.

function ChangeColour(controller, modelId) {
    let selectedColour = document.getElementById("colour_choice").value;
    let price = document.getElementById("price");
    let size = document.getElementById("size_choice");
    let weight = document.getElementById("weight");
    let model = document.getElementById("model");
    let purchaseId = document.getElementById("purchase_id");

    $.ajax(
        {
            type: "POST",
            dataType: "json",
            url: "/" + controller + "/SelectColour",
            data: { id: modelId, colour: selectedColour},
            success: function (data) {
                data = JSON.parse(data);
                selected = data[0];
                setPhoto(controller, selected.ThumbNailPhoto);
                price.innerHTML = selected.ListPrice;
                if(weight != null)
                    weight.innerHTML = selected.Weight
                model.innerHTML = selected.ProductNumber
                //Repopulate list of sizes:
                if (size != null) {
                let length = size.options.length
                    for (let i = 0; i < length; i++) {
                        size.remove(0);
                    }
                    for (let i = 0; i < data.length; i++) {
                        let newSize = new Option(data[i].Size);
                        size.add(newSize);
                    }
                }
                //Don't forget to change the value to send when purchasing the bike.
                purchaseId.value = selected.ProductId;
            }
        });
}

function ChangeSize(controller, modelId) {
    let selectedSize = document.getElementById("size_choice").value;
    let selectedColour = document.getElementById("colour_choice").value;
    let price = document.getElementById("price");
    let weight = document.getElementById("weight");
    let model = document.getElementById("model");
    let purchaseId = document.getElementById("purchase_id");

    $.ajax(
        {
            type: "POST",
            dataType: "json",
            url: "/" + controller +"/SelectSize",
            data: { id: modelId, colour: selectedColour, size: selectedSize },
            success: function (data) {
                data = JSON.parse(data);
                selected = data[0];
                price.innerHTML = selected.ListPrice;
                if(weight != null)
                    weight.innerHTML = selected.Weight
                model.innerHTML = selected.ProductNumber
                //Don't forget to change the value to send when purchasing the bike.
                purchaseId.value = selected.ProductId;
            }
        });
}

function setPhoto(controller, selectedImg) {
    let result = "";
    let image = document.getElementById("product_image");
    $.ajax(
        {
            type: "POST",
            dataType: "json",
            url: "/" + controller + "/GenerateImage",
            data: { image: selectedImg },
            success: function (data) {
                //result = data[0];
                data = JSON.parse(data);
                image.src = data
            }
        });
}