﻿namespace BikeStore.Models
{
    public class ResetResultModel
    {
        public bool Success { get; set; }
        public string Email { get; set; }
        public string ErrorMessage { get; set; }

        public ResetResultModel()
        {
            Success = false;
            Email = null;
            ErrorMessage = null;
        }

        public ResetResultModel(bool Success, string Email)
        {
            this.Success = Success;
            this.Email = Email;
        }

        public ResetResultModel(bool Success, string Email, string ErrorMessage)
        {
            this.Success = Success;
            this.Email = Email;
            this.ErrorMessage = ErrorMessage;
        }
    }
}
