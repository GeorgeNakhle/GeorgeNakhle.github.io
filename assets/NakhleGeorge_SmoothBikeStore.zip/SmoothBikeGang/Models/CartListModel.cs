﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BikeStore.Models
{
    public class CartListModel
    {
        public int ProductId { get; set; }
        public string ProductCategory { get; set; }
        public string ProductName { get; set; }
        public decimal ProductCost { get; set; } 
        public int Quantity { get; set; }
        public byte[] ThumbNailPhoto { get; set; }
    }
}
